# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mwd_ext']

package_data = \
{'': ['*']}

install_requires = \
['connect-extension-runner>=24.0.0,<25.0.0']

entry_points = \
{'connect.eaas.ext': ['extension = mwd_ext.extension:MyweatherdemoExtension']}

setup_kwargs = {
    'name': 'myweatherdemo',
    'version': '0.1.0',
    'description': 'Training for DevOps module',
    'long_description': '# Welcome to MyWeatherDemo !\n\n\nTraining for DevOps module\n\n\n\n## License\n\n**MyWeatherDemo** is licensed under the *Apache Software License 2.0* license.\n\n',
    'author': 'Education Team',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
